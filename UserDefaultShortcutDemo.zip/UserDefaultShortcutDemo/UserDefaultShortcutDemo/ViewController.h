//
//  ViewController.h
//  UserDefaultShortcutDemo
//
//  Created by cchhjj on 16/12/8.
//  Copyright © 2016年 CanHe Chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

