//
//  NSObject+UserInfos.m
//
//  Created by cchhjj on 16/11/2.
//  Copyright © 2016年 CanHe Chen. All rights reserved.
//

#import "NSObject+CCHUserInfos.h"
#import <objc/runtime.h>

#define userDefaults [NSUserDefaults standardUserDefaults]

static NSMutableArray *propertyNames;

@implementation NSObject (CCHUserInfos)

// @dynamic ;
//这里是用来消除警告，告诉系统忽略属性的实现
@dynamic ud_userName;
@dynamic ud_passWord;
@dynamic ud_sessionID;
@dynamic ud_htmlIP;
@dynamic ud_appIP;
@dynamic ud_wifiIP;
@dynamic ud_soundOpen;
@dynamic ud_shockOpen;
@dynamic ud_category;
@dynamic ud_num1;
@dynamic ud_num2;
@dynamic ud_myName;













+ (void)load {
    
    //获取全部 PropertyPrefix 的属性名
    if (!propertyNames) {
        unsigned int outCount,index;
        objc_property_t *properties = class_copyPropertyList([self class], &outCount);
        
        propertyNames = [NSMutableArray array];
        
        for (index = 0; index < outCount; index++) {
            objc_property_t property = properties[index];
            
            const char *cPropertyName = property_getName(property);
            
            NSString *name = [[NSString stringWithCString:cPropertyName encoding:NSUTF8StringEncoding] copy];

            if ([name hasPrefix:PropertyPrefix]) {

                [propertyNames addObject:name];
            }

        }
        
        
        free(properties);
    }
    
    NSLog(@"propertyNames %@",propertyNames);

    //交换resolveInstanceMethod的实现
    Method resolveInstanceMethod = class_getClassMethod(self, @selector(resolveInstanceMethod:));
    Method ud_resolveInstanceMethod = class_getClassMethod(self, @selector(ud_resolveInstanceMethod:));
    if (resolveInstanceMethod && ud_resolveInstanceMethod) {
        method_exchangeImplementations(resolveInstanceMethod, ud_resolveInstanceMethod);
    }


}

+ (BOOL)ud_resolveInstanceMethod:(SEL)sel {

    if([self ud_resolveInstanceMethod:sel]){
        return YES;
    }
    
    
    //找不到实现就执行这里，动态添加方法实现
    NSString *propertyName = UD_propertyNameOf(sel);
    if ([propertyNames containsObject:propertyName]) {
        NSString *methodName = NSStringFromSelector(sel);
        if ([methodName hasPrefix:@"set"]) {
            return [self ud_addSetter:sel];
        } else {
            return [self ud_getterSetter:sel];
        }
    }
    
    return NO;
}

+ (BOOL)ud_addSetter:(SEL)aSEL {

    class_addMethod([self class], aSEL, (IMP)__UD__object_dynamicSetterIMP, "v@:@");
    return YES;
}

+ (BOOL)ud_getterSetter:(SEL)aSEL {
    class_addMethod([self class], aSEL, (IMP)__UD__object_dynamicGetterIMP, "@@:");
    return YES;
}

NSString* UD_propertyNameOf(SEL aSEL)
{
    NSString *name = NSStringFromSelector(aSEL);
    if ([name hasPrefix:@"set"])
    {
        NSString *cap = [name substringWithRange:NSMakeRange(3, 1)];
        NSString *tail = [[name substringFromIndex:4] stringByReplacingOccurrencesOfString:@":" withString:@""];
        name = [NSString stringWithFormat:@"%@%@", [cap lowercaseString], tail];
        return name;
    }
    else
    {
        return name;
    }
}

void __UD__object_dynamicSetterIMP(id self, SEL _cmd, id arg) {
    
    NSString *propertyName = UD_propertyNameOf(_cmd);
    if ([propertyNames containsObject:propertyName]) {
        
        if (arg) {
            [userDefaults setObject:arg forKey:propertyName];
            [userDefaults synchronize];
        }
        
    }
    
    
}

id __UD__object_dynamicGetterIMP(id self, SEL _cmd) {
    
    NSString *propertyName = UD_propertyNameOf(_cmd);
    if ([propertyNames containsObject:propertyName]) {
        
        return [userDefaults objectForKey:propertyName];
        
    } else {
        return nil;
    }
    
}
-(void)clearValue{
    for (NSString *myKey in propertyNames) {
        [userDefaults removeObjectForKey:myKey];
        
    }
    [userDefaults synchronize];
}


@end
