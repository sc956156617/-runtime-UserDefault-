//
//  NSObject+UserInfos.h
//
//  Created by cchhjj on 16/11/2.
//  Copyright © 2016年 CanHe Chen. All rights reserved.
//

#import <Foundation/Foundation.h>


//默认的前缀是ud_，可以自定义。声明的属性的前缀一定要同PropertyPrefix相同
#define PropertyPrefix @"ud_"

/*
 //该文件志在简化NSUserDefaults的操作并统一管理；把该文件导入到pch文件里，方便使用。
 
 //这里的属性只能声明为对象，不能用（不支持）基本类型。请用NSNumber转成对象来保存
 //只支持NSUserDefaults可以保存的类型
 //这里的对象只是为了方便保存在NSUserDefaults里。不能完全当正常的属性来使用，但读写方式是一样的。
 //只用在h文件里声明属性就可以使用。因为没有实现方法，xcode会有警告，可以在m文件里用@dynamic propertyName;来消除警告。
 */

@interface NSObject (CCHUserInfos)
//方便声明
//@property (copy, nonatomic) NSString *ud_


//以下属性只是用来测试的。
@property (copy, nonatomic) NSString *ud_category;

@property (copy, nonatomic) NSString *ud_userName;

@property (copy, nonatomic) NSString *ud_passWord;

@property (copy, nonatomic) NSString *ud_sessionID;

@property (copy, nonatomic) NSString *ud_htmlIP;

@property (copy, nonatomic) NSString *ud_appIP;

@property (copy, nonatomic) NSString *ud_wifiIP;

@property (strong, nonatomic) NSNumber *ud_soundOpen;
@property (strong, nonatomic) NSNumber *ud_shockOpen;

@property (strong, nonatomic) NSNumber *ud_num1;
@property (strong, nonatomic) NSNumber *ud_num2;
@property (copy, nonatomic) NSString *ud_myName;
-(void)clearValue;
@end
