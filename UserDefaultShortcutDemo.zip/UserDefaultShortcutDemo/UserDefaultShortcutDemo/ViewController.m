//
//  ViewController.m
//  UserDefaultShortcutDemo
//
//  Created by cchhjj on 16/12/8.
//  Copyright © 2016年 CanHe Chen. All rights reserved.
//

#import "ViewController.h"
#import "NSObject+CCHUserInfos.h"
@interface ViewController ()

@end

@implementation ViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.ud_appIP = @"156.156.148.78";
    NSLog(@"self.du_appip:%@",self.ud_appIP);
    
//    self.ud_shockOpen = @(YES);
    NSLog(@"self.ud_shockOpen %d",self.ud_shockOpen.boolValue);
    
//    self.ud_num1 = @(3.14);
    NSLog(@"self.ud_num1 %.2f",self.ud_num1.floatValue);
    
//    self.ud_num2 = @(54545454);
    NSLog(@"self.ud_num2 %ld",self.ud_num2.integerValue);
    //....
    
//    self.ud_myName=@"董鹏";
    NSLog(@"dp:%@",self.ud_myName);
    
    [self clearValue];
    
    
}






@end
