//
//  main.m
//  UserDefaultDP
//
//  Created by IOS on 16/12/8.
//  Copyright © 2016年 琅琊榜. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
